var searchData=
[
  ['begin',['begin',['../class_record.html#a4f65302d712b34e19b8bac9aeff06016',1,'Record::begin()'],['../class_table.html#a020add8ec0eb6fec40695c605adc9038',1,'Table::begin()']]]
];
