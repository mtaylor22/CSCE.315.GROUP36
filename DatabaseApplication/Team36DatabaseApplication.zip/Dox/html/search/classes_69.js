var searchData=
[
  ['invalidoperationerror',['InvalidOperationError',['../class_invalid_operation_error.html',1,'']]],
  ['invalidtypeerror',['InvalidTypeError',['../class_invalid_type_error.html',1,'']]],
  ['ioerror',['IOError',['../class_i_o_error.html',1,'']]]
];
