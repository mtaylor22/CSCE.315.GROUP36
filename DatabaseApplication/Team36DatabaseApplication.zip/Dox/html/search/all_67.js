var searchData=
[
  ['get',['get',['../class_record.html#a5b6392211018031e67e4d4c599046061',1,'Record']]]
];
