var searchData=
[
  ['record',['Record',['../class_record.html',1,'Record'],['../class_record.html#ae8ee53ffec6ff4dac9911517d47e86a5',1,'Record::Record()'],['../class_record.html#af6b85f753bb8dfea3e29728490b3d2a3',1,'Record::Record(vector&lt; pair&lt; string, string &gt; &gt; entries)']]],
  ['recorditerator',['RecordIterator',['../class_record.html#ae8a1c90a4d896429d087ccc1f205f9b7',1,'Record']]],
  ['recordtype',['RecordType',['../class_table.html#af8f9ec96ecaa35a2e65312b74ddfeae6',1,'Table']]],
  ['rename_5fcolumn',['rename_column',['../class_table.html#ac5c19a55c8527ee267360cd1332317bd',1,'Table']]],
  ['rowdoesnotexisterror',['RowDoesNotExistError',['../class_row_does_not_exist_error.html',1,'']]]
];
