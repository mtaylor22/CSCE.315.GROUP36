var searchData=
[
  ['max',['max',['../class_table.html#abb7aff3403f246965d7557ab592110dd',1,'Table']]],
  ['merge',['merge',['../class_database.html#a50aa2c5fbadfc54f2e098809d8b889ca',1,'Database']]],
  ['min',['min',['../class_table.html#a2a4882f99726fba725314e2625ed37ae',1,'Table']]]
];
