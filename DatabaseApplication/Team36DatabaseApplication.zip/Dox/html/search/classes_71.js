var searchData=
[
  ['querysyntaxerror',['QuerySyntaxError',['../class_query_syntax_error.html',1,'']]]
];
