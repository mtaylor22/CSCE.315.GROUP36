var searchData=
[
  ['query',['query',['../class_database.html#a0520f606f68e207ca972e1c84b625805',1,'Database']]],
  ['querysyntaxerror',['QuerySyntaxError',['../class_query_syntax_error.html',1,'']]]
];
