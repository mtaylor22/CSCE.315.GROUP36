#define BOOST_TEST_MODULE DatabaseTest
#include <boost/test/unit_test.hpp>